package com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.po.Order;

@Repository
@Mapper
public interface UserOrderDao {

	int Order(Order order);

	List<Order> MyorderedPrize(@Param("createrid")Integer id);

	void Cancel(int id);

	List<Order> MycancelledPrize(@Param("createrid")Integer id);

	List<Order> MyrecievedPrize(@Param("createrid")Integer id);

}
