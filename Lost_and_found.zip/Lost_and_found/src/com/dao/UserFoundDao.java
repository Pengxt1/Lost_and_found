package com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.po.Found;

@Repository
@Mapper
public interface UserFoundDao {
	public List<Found> toSeeTrusteeship(int id);
	public List<Found> toSee(int id);

	public void Send(Found found);
	public List<Found> toSeeMyTrusteeship(Integer id);
	public List<Found> toDeleteSelect(Integer id);

	public void Delete(int id);

	public void Find(int id);

	public void UnFind(int id);



}
