package com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;


import com.po.Prize;

@Repository
@Mapper
public interface UserPrizeDao {

	List<Prize> selectAllPrize();

	Prize selectPrizeById(int id);

	void reduceAmount(@Param("id")Integer id, @Param("reduce")int reduce);

	void addAmount(@Param("id")int prizeid,@Param("add")int i);


}
