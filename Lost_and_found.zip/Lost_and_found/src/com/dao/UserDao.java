package com.dao;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.po.Buser;

@Repository
@Mapper
public interface UserDao {

	public Buser registerselect(Buser buser) ;

	public void register(Buser buser) ;

	public Buser loginselect(Buser buser);



}
