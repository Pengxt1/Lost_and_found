package com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.po.Lost;

@Repository
@Mapper
public interface AdminLostDao {

	List<Lost> toDeleteSelect();

	void Delete(int id);

	int toCountByTypename(String ltypename);

}
