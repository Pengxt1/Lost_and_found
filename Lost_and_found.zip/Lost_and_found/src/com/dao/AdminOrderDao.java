package com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.po.Order;

@Repository
@Mapper
public interface AdminOrderDao {

	List<Order> untreatedOrder();

	void Cancel(int id);

	List<Order> TreatedOrder();

	void Recieve(int id);

	List<Order> CancelOrder();

}
