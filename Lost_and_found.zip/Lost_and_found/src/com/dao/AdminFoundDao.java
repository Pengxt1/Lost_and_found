package com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.po.Found;

@Repository
@Mapper
public interface AdminFoundDao {
	List<Found> toTFound();
	List<Found> toNoTFound();
	void Trusteeship(int id);
	void Delete(int id);

	int toCountByTypename(String ftypename);

	void Send(Found found);
	void Find(int id);
	void UnFind(int id);


}
