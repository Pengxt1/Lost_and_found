package com.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.po.Buser;

@Repository
@Mapper
public interface UserUserDao {

	void changePwd(Buser buser);

	void reduceCredit(@Param("id")Integer id,@Param("pcredit") int pcredit);

	void addCredit(@Param("id")Integer id,@Param("pcredit") int pcredit);

}
