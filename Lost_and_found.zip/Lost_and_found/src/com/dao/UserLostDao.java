package com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.po.Lost;

@Repository
@Mapper
public interface UserLostDao {


	public List<Lost> toSee(int id);

	public void Send(Lost lost);
	
	public List<Lost> toDeleteSelect(Integer id);

	public void Delete(int id);

	public void Find(int id);

	public void UnFind(int id);

	

}
