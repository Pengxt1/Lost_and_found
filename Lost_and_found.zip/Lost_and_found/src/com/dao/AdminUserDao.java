package com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.po.Buser;

@Repository
@Mapper
public interface AdminUserDao {
	public List<Buser> userInfo();

	public int deleteuserManager(Integer id);

	public void supend(Integer id);

	public void unlock(Integer id);

	public void addCredit(@Param("createrid")int id,@Param("add")int add);

	public void reduceCredit(@Param("createrid")int id,@Param("reduce")int reduce);

	public Buser selectUserById(@Param("id")int createrid);
}
