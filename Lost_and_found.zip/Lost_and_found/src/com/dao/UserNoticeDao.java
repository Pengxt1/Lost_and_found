package com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.po.Notice;

@Repository
@Mapper
public interface UserNoticeDao {

	List<Notice> seeallselect();

	Notice selectANotice(Integer id);

}
