package com.service.before;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.dao.UserPrizeDao;
import com.po.Prize;



@Service
public class UserPrizeServiceImpl implements UserPrizeService {
	@Autowired
	private UserPrizeDao userPrizeDao;
	
	
	@Override
	public String selectAllPrize(Model model) {
		List<Prize> prizelist=userPrizeDao.selectAllPrize();
		model.addAttribute("prizelist",prizelist);
		return "before/selectAllPrize";
	}


}
