package com.service.before;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import com.po.Lost;

public interface UserLostService {
	
	public String toSee(Model model,HttpSession session);

	public String toSend(Model model);

	public String Send(Lost lost, Model model,HttpSession session,HttpServletRequest request);

	public String toDelete(Model model,HttpSession session);

	public String Delete(int id);

	public String Find(int id);

	public String UnFind(int id);

}
