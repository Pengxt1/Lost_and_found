package com.service.before;

import javax.servlet.http.HttpSession;
import com.po.Order;
import org.springframework.ui.Model;

public interface UserOrderService {

	String Order(int id, Model model, HttpSession session);

	String MyorderedPrize(Model model,HttpSession session);

	String Cancel(Order order,HttpSession session);

	String MycancelledPrize(Model model, HttpSession session);

	String MyrecievedPrize(Model model, HttpSession session);

}
