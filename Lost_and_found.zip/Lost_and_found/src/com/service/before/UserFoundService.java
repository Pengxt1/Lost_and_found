package com.service.before;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import com.po.Found;

public interface UserFoundService {

	public String toSeeTrusteeship(Model model,HttpSession session);
	public String toSee(Model model,HttpSession session);

	public String toSend(Model model);

	public String Send(Found found, Model model, HttpSession session,HttpServletRequest request);

	public String toSeeMyTrusteeship(Model model, HttpSession session);
	public String toDelete(Model model, HttpSession session);

	public String Delete(int id);

	public String UnFind(int id);

	public String Find(int id);




}
