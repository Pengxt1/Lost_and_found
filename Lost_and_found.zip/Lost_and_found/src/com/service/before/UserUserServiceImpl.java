package com.service.before;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;


import com.dao.UserUserDao;
import com.po.Buser;

@Service
public class UserUserServiceImpl implements UserUserService{
	@Autowired
	private UserUserDao useruserdao;
	@Override
	public String changePwd(String oldbpwd,String newbpwd, Model model, HttpSession session) {
		Buser buser=(Buser) session.getAttribute("buser");
		if(oldbpwd.equals(buser.getBpwd())) {
			buser.setBpwd(newbpwd);
			useruserdao.changePwd(buser);
			model.addAttribute("msg","提示：密码修改成功！");
			session.setAttribute("buser", buser);
			return "before/changePwd";
		}
		model.addAttribute("msg","提示：旧密码错误，请重新输入！");
		return "before/changePwd";
	}

}
