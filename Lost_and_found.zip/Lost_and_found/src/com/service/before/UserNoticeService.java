package com.service.before;

import org.springframework.ui.Model;

public interface UserNoticeService {

	String seeallselect(Model model);

	String selectANotice(Model model, Integer id);

}
