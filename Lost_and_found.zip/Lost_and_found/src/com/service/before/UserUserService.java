package com.service.before;

import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

public interface UserUserService {
	String changePwd(String oldbpwd,String newbpwd, Model model, HttpSession session);

}
