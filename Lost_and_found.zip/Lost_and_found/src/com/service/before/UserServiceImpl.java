package com.service.before;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.dao.UserDao;
import com.po.Buser;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	private UserDao userdao;

	@Override
	public String register(Buser buser,Model model) {
		Buser buser1=userdao.registerselect(buser);
		if(buser1!=null) {
			model.addAttribute("msg","提示：邮箱已注册,请更换邮箱");
			return "before/register";
		}
		else {
			userdao.register(buser);
			model.addAttribute("msg","提示：注册成功，请返回登录");
			return "before/register";
		}
	}

	@Override
	public String login(Buser buser, Model model, HttpSession session) {
		Buser buser1=userdao.loginselect(buser);
		if(buser1!=null&&buser1.getBavailable().equals("1")) {
			session.setAttribute("buser", buser1);
			return "before/main";
		}
		else if(buser1!=null&&!buser1.getBavailable().equals("1")){
			model.addAttribute("msg","提示：该用户已被禁用，请联系后台管理员");
			return "before/login";
		}
		model.addAttribute("msg","提示：邮箱或密码错误");
		return "before/login";
	}
	
}
