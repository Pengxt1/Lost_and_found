package com.service.before;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.dao.UserOrderDao;
import com.dao.UserPrizeDao;
import com.dao.UserUserDao;
import com.po.Buser;
import com.po.Order;
import com.po.Prize;

@Service
public class UserOrderServiceImpl implements UserOrderService {
	@Autowired
	private UserOrderDao userOrderDao;
	@Autowired
	private UserPrizeDao userPrizeDao;
	@Autowired
	private UserUserDao userUserDao;
	@Override
	public String Order(int id, Model model, HttpSession session) {
		Buser buser=(Buser)session.getAttribute("buser");
		Prize prize=userPrizeDao.selectPrizeById(id);
		if(prize==null) {
			return "该奖品不存在了";
		}else if(prize.getPamount()<=0) {
			return "该奖品目前余量为0，无法预约兑换";
		}else if(prize.getPcredit()>buser.getCredit()) {
			return "你的积分不足，无法预约兑换";
		}else {
			Order order=new Order();
			order.setPrizeid(prize.getId());
			order.setPrizename(prize.getPrizename());
			order.setPrizedescribe(prize.getPrizedescribe());
			order.setPimage(prize.getPimage());
			order.setPcredit(prize.getPcredit());
			order.setCreaterid(buser.getId());
			order.setState("0");
			userOrderDao.Order(order);//预约
			userPrizeDao.reduceAmount(prize.getId(),1);//奖品减少
			userUserDao.reduceCredit(buser.getId(),prize.getPcredit());//扣分
			return "预约成功";
		}
	}
	@Override
	public String MyorderedPrize(Model model,HttpSession session) {
		Buser buser=(Buser)session.getAttribute("buser");
		model.addAttribute("orderlist",userOrderDao.MyorderedPrize(buser.getId()));
		return "before/MyorderedPrize";
	}
	@Override
	public String Cancel(Order order,HttpSession session) {
		Buser buser=(Buser)session.getAttribute("buser");
		userOrderDao.Cancel(order.getId());//取消
		userPrizeDao.addAmount(order.getPrizeid(),1);//奖品增加
		userUserDao.addCredit(buser.getId(),order.getPcredit());//回分
		return "forward:/userOrder/MyorderedPrize";
	}
	@Override
	public String MycancelledPrize(Model model, HttpSession session) {
		
		Buser buser=(Buser)session.getAttribute("buser");
		model.addAttribute("orderlist",userOrderDao.MycancelledPrize(buser.getId()));
		return "before/MycancelledPrize";
	}
	@Override
	public String MyrecievedPrize(Model model, HttpSession session) {
		Buser buser=(Buser)session.getAttribute("buser");
		model.addAttribute("orderlist",userOrderDao.MyrecievedPrize(buser.getId()));
		return "before/MyrecievedPrize";
	}

}
