package com.service.before;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.dao.UserNoticeDao;

@Service
public class UserNoticeServiceImpl implements UserNoticeService{
	@Autowired 
	private UserNoticeDao userNoticeDao;
	@Override
	public String seeallselect(Model model) {
		model.addAttribute("allNotices", userNoticeDao.seeallselect());
		return "before/seeAllNotice";
	}
	@Override
	public String selectANotice(Model model, Integer id) {
		model.addAttribute("notice", userNoticeDao.selectANotice(id));
		return "before/noticeDetail";
	}

}
