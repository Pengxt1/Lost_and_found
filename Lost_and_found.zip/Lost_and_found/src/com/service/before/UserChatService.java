package com.service.before;

import org.springframework.ui.Model;

public interface UserChatService {

	String toChat(String createrid,Model model);

	String toChat1();

}
