package com.service.before;

import java.io.File;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.dao.UserFoundDao;
import com.dao.UserTypeDao;
import com.po.Buser;
import com.po.Found;

@Service
public class UserFoundServiceImpl implements UserFoundService{
	@Autowired
	private UserFoundDao userFoundDao;
	@Autowired
	private UserTypeDao userTypeDao;
	@Override
	public String toSeeTrusteeship(Model model,HttpSession session) {
		Buser buser=(Buser)session.getAttribute("buser");
		int id=buser.getId();
		model.addAttribute("foundlist",userFoundDao.toSeeTrusteeship(id));
		return "before/toSeeFoundTrusteeship";
	}
	@Override
	public String toSee(Model model,HttpSession session) {
		Buser buser=(Buser)session.getAttribute("buser");
		int id=buser.getId();
		model.addAttribute("foundlist",userFoundDao.toSee(id));
		return "before/toSeeFound";
	}
	@Override
	public String toSend(Model model) {
		model.addAttribute("allTypes",userTypeDao.selectGoodsType());
		return "before/toSendFound";
	}
	@Override
	public String Send(Found found, Model model, HttpSession session,HttpServletRequest request) {
		String newFileName="";
		String fileName=found.getFfile().getOriginalFilename();
		if(fileName.length()>0) {
			System.out.println(request.getServletContext().getRealPath(""));
			String realpath=request.getServletContext().getRealPath("fimages");
			String fileType=fileName.substring(fileName.lastIndexOf('.'));
			newFileName=UUID.randomUUID().toString()+fileType;
			found.setFimage(newFileName);
			File targetFile=new File(realpath,newFileName);
			if(!targetFile.exists()) {
				targetFile.mkdirs();
			}
			try {
				found.getFfile().transferTo(targetFile);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		Buser buser=(Buser)session.getAttribute("buser");
		found.setCreaterid(buser.getId());
		userFoundDao.Send(found);
		model.addAttribute("msg","提示：发布成功");
		return "forward:/userFound/toSend";
	}
	@Override
	public String toSeeMyTrusteeship(Model model,HttpSession session) {
		Buser buser=(Buser)session.getAttribute("buser");
		model.addAttribute("selffoundlist",userFoundDao.toSeeMyTrusteeship(buser.getId()));
		return "before/toSeeMyFoundTrusteeship";
	}
	@Override
	public String toDelete(Model model,HttpSession session) {
		Buser buser=(Buser)session.getAttribute("buser");
		model.addAttribute("selffoundlist",userFoundDao.toDeleteSelect(buser.getId()));
		return "before/toDeleteFound";
	}
	@Override
	public String Delete(int id) {
		userFoundDao.Delete(id);
		return "forward:/userFound/toDelete";
	}
	@Override
	public String Find(int id) {
		userFoundDao.Find(id);
		return "forward:/userFound/toDelete";
	}
	@Override
	public String UnFind(int id) {
		userFoundDao.UnFind(id);
		return "forward:/userFound/toDelete";
	}



}
