package com.service.before;

import java.io.File;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.dao.UserLostDao;
import com.dao.UserTypeDao;
import com.po.Buser;
import com.po.Lost;

@Service
public class UserLostServiceImpl implements UserLostService{
	@Autowired
	private UserLostDao userLostDao;
	@Autowired
	private UserTypeDao userTypeDao;

	@Override
	public String toSee(Model model,HttpSession session) {
		Buser buser=(Buser)session.getAttribute("buser");
		int id=buser.getId();
		model.addAttribute("lostlist",userLostDao.toSee(id));
		return "before/toSeeLost";
	}
	@Override
	public String toSend(Model model) {
		model.addAttribute("allTypes",userTypeDao.selectGoodsType());
		return "before/toSendLost";
	}
	
	
	@Override
	public String Send(Lost lost,Model model,HttpSession session,HttpServletRequest request) {
		String newFileName="";
		String fileName=lost.getLfile().getOriginalFilename();
		if(fileName.length()>0) {
			String realpath=request.getServletContext().getRealPath("limages");
			String fileType=fileName.substring(fileName.lastIndexOf('.'));
			newFileName=UUID.randomUUID().toString()+fileType;
			lost.setLimage(newFileName);
			File targetFile=new File(realpath,newFileName);
			if(!targetFile.exists()) {
				targetFile.mkdirs();
			}
			try {
				lost.getLfile().transferTo(targetFile);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		Buser buser=(Buser)session.getAttribute("buser");
		lost.setCreaterid(buser.getId());
		userLostDao.Send(lost);
		model.addAttribute("msg","提示：发布成功");
		return "forward:/userLost/toSend";
	}

	@Override
	public String toDelete(Model model,HttpSession session) {
		Buser buser=(Buser)session.getAttribute("buser");
		model.addAttribute("selflostlist",userLostDao.toDeleteSelect(buser.getId()));
		return "before/toDeleteLost";
	}
	@Override
	public String Delete(int id) {
		userLostDao.Delete(id);
		return "forward:/userLost/toDelete";
	}
	@Override
	public String Find(int id) {
		userLostDao.Find(id);
		return "forward:/userLost/toDelete";
	}
	@Override
	public String UnFind(int id) {
		userLostDao.UnFind(id);
		return "forward:/userLost/toDelete";
	}
	

}
