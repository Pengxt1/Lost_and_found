package com.service.before;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

@Service
public class UserChatServiceImpl implements UserChatService{

	@Override
	public String toChat(String createrid,Model model) {
		model.addAttribute("createrid",createrid);
		return "before/chat";
	}

	@Override
	public String toChat1() {
		// TODO Auto-generated method stub
		return "before/chat1";
	}

}
