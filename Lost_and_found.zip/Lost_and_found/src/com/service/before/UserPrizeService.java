package com.service.before;


import org.springframework.ui.Model;

public interface UserPrizeService {

	String selectAllPrize(Model model);

	

}
