package com.service.admin;

import java.io.File;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.dao.AdminPrizeDao;
import com.po.Prize;

@Service
public class AdminPrizeServiceImpl implements AdminPrizeService {
	@Autowired
	private AdminPrizeDao adminPrizeDao;
	@Override
	public String toManagerPrize(Model model) {
		List<Prize> prizelist=adminPrizeDao.selectAllPrize();
		model.addAttribute("prizelist",prizelist);
		return "admin/toManagerPrize";
	}
	@Override
	public String addPrize(Prize prize,HttpSession session, HttpServletRequest request) {
		String newFileName="";
		String fileName=prize.getPfile().getOriginalFilename();
		if(fileName.length()>0) {
			System.out.println(request.getServletContext().getRealPath(""));
			String realpath=request.getServletContext().getRealPath("pimages");
			String fileType=fileName.substring(fileName.lastIndexOf('.'));
			newFileName=UUID.randomUUID().toString()+fileType;
			prize.setPimage(newFileName);
			File targetFile=new File(realpath,newFileName);
			if(!targetFile.exists()) {
				targetFile.mkdirs();
			}
			try {
				prize.getPfile().transferTo(targetFile);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		adminPrizeDao.add(prize);
		return "forward:/adminPrize/toManagerPrize";
	}
	@Override
	public String Delete(int id) {
		adminPrizeDao.Delete(id);
		return "forward:/adminPrize/toManagerPrize";
	}
	@Override
	public String In(Prize prize) {
		adminPrizeDao.In(prize);
		return "forward:/adminPrize/toManagerPrize";
	}
	@Override
	public String Out(Prize prize) {
		adminPrizeDao.Out(prize);
		return "forward:/adminPrize/toManagerPrize";
	}

}
