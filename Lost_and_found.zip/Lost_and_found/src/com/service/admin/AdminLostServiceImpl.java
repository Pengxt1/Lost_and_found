package com.service.admin;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.dao.AdminLostDao;
import com.dao.AdminTypeDao;
import com.po.GoodsType;
import com.po.Lost;

@Service
public class AdminLostServiceImpl implements AdminLostService {
	@Autowired
	private AdminLostDao adminLostDao;
	@Autowired
	private AdminTypeDao adminTypeDao;

	@Override
	public String toDelete(Model model) {
		model.addAttribute("lostlist",adminLostDao.toDeleteSelect());
		return "admin/toDeleteLost";
	}

	@Override
	public String Delete(int id) {
		adminLostDao.Delete(id);
		return "forward:/adminLost/toDelete";
	}

	@Override
	public String toCount(Model model) {
		List<GoodsType> alltypes=adminTypeDao.selectGoodsType();
		String maxtype = null;
		int maxcount=0;
		for(int i=0;i<alltypes.size();i++) {
			String typename=alltypes.get(i).getTypename();
			int count=adminLostDao.toCountByTypename(typename);
			alltypes.get(i).setCount(count);
			if(maxcount<=count) {
				maxcount=count;
				maxtype=alltypes.get(i).getTypename();
			}
		}
		model.addAttribute("alltypes",alltypes);
		model.addAttribute("maxtype",maxtype);
		model.addAttribute("maxcount",maxcount);
		return "admin/toCountLost";
	}
}
