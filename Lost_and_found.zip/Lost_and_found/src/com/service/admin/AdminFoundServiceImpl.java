package com.service.admin;

import java.io.File;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.dao.AdminFoundDao;
import com.dao.AdminTypeDao;
import com.dao.AdminUserDao;
import com.po.Buser;
import com.po.Found;
import com.po.GoodsType;

@Service
public class AdminFoundServiceImpl implements AdminFoundService {
	@Autowired
	private AdminFoundDao adminFoundDao;
	@Autowired
	private AdminTypeDao adminTypeDao;
	@Autowired
	private AdminUserDao adminUserDao;

	@Override
	public String toNoTFound(Model model) {
		model.addAttribute("foundlist",adminFoundDao.toNoTFound());
		return "admin/toNoTFound";
	}

	@Override
	public String Trusteeship(int id,int createrid) {
		adminUserDao.addCredit(createrid, 50);
		adminFoundDao.Trusteeship(id);
		return "forward:/adminFound/toNoTFound";
	}
	@Override
	public String DeleteNoT(int id) {
		adminFoundDao.Delete(id);
		return "forward:/adminFound/toNoTFound";
	}
	@Override
	public String toTFound(Model model) {
		model.addAttribute("foundlist",adminFoundDao.toTFound());
		return "admin/toTFound";
	}
	@Override
	public String DeleteT(int id) {
		adminFoundDao.Delete(id);
		return "forward:/adminFound/toTFound";
	}
	@Override
	public String Find(int id,int createrid) {
		adminFoundDao.Find(id);
		adminUserDao.addCredit(createrid,50);
		return "forward:/adminFound/toTFound";
	}
	@Override
	public String UnFind(int id,int createrid) {
		adminFoundDao.UnFind(id);
		adminUserDao.reduceCredit(createrid,50);
		return "forward:/adminFound/toTFound";
	}

	@Override
	public String toCount(Model model) {
		List<GoodsType> alltypes=adminTypeDao.selectGoodsType();
		String maxtype = null;
		int maxcount=0;
		for(int i=0;i<alltypes.size();i++) {
			String typename=alltypes.get(i).getTypename();
			int count=adminFoundDao.toCountByTypename(typename);
			alltypes.get(i).setCount(count);
			if(maxcount<=count) {
				maxcount=count;
				maxtype=alltypes.get(i).getTypename();
			}
		}
		model.addAttribute("alltypes",alltypes);
		model.addAttribute("maxtype",maxtype);
		model.addAttribute("maxcount",maxcount);
		return "admin/toCountFound";
	}

	@Override
	public String toSend(Model model) {
		model.addAttribute("allTypes",adminTypeDao.selectGoodsType());
		return "admin/toSendFound";
	}

	@Override
	public String Send(Found found, Model model, HttpSession session, HttpServletRequest request) {
		String newFileName="";
		String fileName=found.getFfile().getOriginalFilename();
		if(fileName.length()>0) {
			System.out.println(request.getServletContext().getRealPath(""));
			String realpath=request.getServletContext().getRealPath("fimages");
			String fileType=fileName.substring(fileName.lastIndexOf('.'));
			newFileName=UUID.randomUUID().toString()+fileType;
			found.setFimage(newFileName);
			File targetFile=new File(realpath,newFileName);
			if(!targetFile.exists()) {
				targetFile.mkdirs();
			}
			try {
				found.getFfile().transferTo(targetFile);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		adminFoundDao.Send(found);
		adminUserDao.addCredit(found.getCreaterid(), 50);
		model.addAttribute("msg","提示：发布成功");
		return "forward:/adminFound/toSend";
	}



}
