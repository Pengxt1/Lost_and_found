package com.service.admin;

import org.springframework.ui.Model;

public interface AdminLostService {

	String toDelete(Model model);

	String Delete(int id);

	String toCount(Model model);

}
