package com.service.admin;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import com.po.Found;

public interface AdminFoundService {
	String toTFound(Model model);
	String toNoTFound(Model model);
	
	String Trusteeship(int id,int createrid);
	String DeleteT(int id);
	String DeleteNoT(int id);

	String toCount(Model model);

	String toSend(Model model);

	String Send(Found found, Model model, HttpSession session, HttpServletRequest request);
	String Find(int id,int createrid);
	String UnFind(int id,int createrid);
	

	

}
