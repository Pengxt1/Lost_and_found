package com.service.admin;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import com.po.Prize;

public interface AdminPrizeService {

	String toManagerPrize(Model model);

	String addPrize(Prize prize,HttpSession session, HttpServletRequest request);

	String Delete(int id);

	String In(Prize prize);

	String Out(Prize prize);

}
