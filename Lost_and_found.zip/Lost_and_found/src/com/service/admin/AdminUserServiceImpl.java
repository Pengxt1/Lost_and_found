package com.service.admin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import com.dao.AdminUserDao;
@Service
public class AdminUserServiceImpl implements AdminUserService{
	@Autowired
	private AdminUserDao adminUserDao;
	@Override
	public String userInfo(Model model) {
		model.addAttribute("userList", adminUserDao.userInfo());
		return "admin/userManager";
	}
	@Override
	public String deleteuserManager(Integer id) {
		adminUserDao.deleteuserManager(id);
		return "forward:/adminUser/userInfo";
	}
	@Override
	public String userSuspend(Model model) {
		model.addAttribute("userList", adminUserDao.userInfo());
		return "admin/userSuspend";
	}
	@Override
	public String suspend(Integer id) {
		// TODO Auto-generated method stub
		adminUserDao.supend(id);
		return "forward:/adminUser/userSuspend";
	}
	@Override
	public String unlock(Integer id) {
		// TODO Auto-generated method stub
		adminUserDao.unlock(id);
		return "forward:/adminUser/userSuspend";
	}
	@Override
	public String toChangeCredit(Model model) {
		model.addAttribute("userList", adminUserDao.userInfo());
		return "admin/toChangeCredit";
	}
	@Override
	public String reduceCredit(int id, int reduce) {
		adminUserDao.reduceCredit(id, reduce);
		return "forward:/adminUser/toChangeCredit";
	}
	@Override
	public String addCredit(int id, int add) {
		adminUserDao.addCredit(id, add);
		return "forward:/adminUser//toChangeCredit";
	}

}
