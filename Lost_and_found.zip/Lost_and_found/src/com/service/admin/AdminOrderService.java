package com.service.admin;

import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import com.po.Order;

public interface AdminOrderService {

	String untreatedOrder(Model model);
	String Cancel(Order order,HttpSession session);
	String TreatedOrder(Model model);
	String Recieve(int id, int createrid, String bemail, String bpwd);
	String CancelOrder(Model model);
}
