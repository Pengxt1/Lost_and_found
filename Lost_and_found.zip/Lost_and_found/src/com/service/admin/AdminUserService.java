package com.service.admin;

import org.springframework.ui.Model;

public interface AdminUserService {
	public String userInfo(Model model);

	public String deleteuserManager(Integer id);

	public String userSuspend(Model model);

	public String suspend(Integer id);

	public String unlock(Integer id);

	public String toChangeCredit(Model model);

	public String reduceCredit(int id, int reduce);


	public String addCredit(int id, int add);
}
