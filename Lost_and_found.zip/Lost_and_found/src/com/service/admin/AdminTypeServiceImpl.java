package com.service.admin;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import com.dao.AdminTypeDao;
import com.po.GoodsType;
@Service
public class AdminTypeServiceImpl implements AdminTypeService{
	@Autowired
	private AdminTypeDao adminTypeDao;

	@Override
	public String toAddType(Model model) {
		model.addAttribute("allTypes", adminTypeDao.selectGoodsType());
		return "admin/addType";
	}
	@Override
	public String addType(String typename,Model model) {
		GoodsType goodtypes=adminTypeDao.selectTypeByName(typename);
		if(goodtypes==null) {
			adminTypeDao.addType(typename);
			model.addAttribute("msg","提示：添加成功");
			return "forward:/adminType/toAddType";
		}
		model.addAttribute("msg","提示：添加失败，该类型已存在");
		return "forward:/adminType/toAddType";
	}
	@Override
	public String toDeleteType(Model model) {
		model.addAttribute("allTypes", adminTypeDao.selectGoodsType());
		return "admin/deleteType";
	}
	@Override
	public String deleteType(Integer id) {
		adminTypeDao.deleteType(id);
		return "forward:/adminType/toDeleteType";
	}
}
