package com.service.admin;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.dao.AdminOrderDao;
import com.dao.AdminPrizeDao;
import com.dao.AdminUserDao;
import com.po.Buser;
import com.po.Order;

@Service
public class AdminOrderServiceImpl implements AdminOrderService {
	@Autowired
	private AdminOrderDao adminOrderDao;
	@Autowired
	private AdminPrizeDao adminPrizeDao;
	@Autowired
	private AdminUserDao adminUserDao;
	@Override
	public String untreatedOrder(Model model) {
		model.addAttribute("orderlist",adminOrderDao.untreatedOrder());
		return "admin/untreatedOrder";
	}
	@Override
	public String Cancel(Order order,HttpSession session) {
		adminOrderDao.Cancel(order.getId());//取消
		adminPrizeDao.addAmount(order.getPrizeid(),1);//奖品增加
		adminUserDao.addCredit(order.getCreaterid(),order.getPcredit());//回分
		return "forward:/adminOrder/untreatedOrder";
	}
	@Override
	public String Recieve(int id, int createrid, String bemail, String bpwd) {
		Buser buser=adminUserDao.selectUserById(createrid);
		if(buser.getBemail().equals(bemail)&&buser.getBpwd().equals(bpwd)) {
			adminOrderDao.Recieve(id);
			return "领取成功";
		}else {
			return "邮箱或密码错误，领取失败";
		}
	}
	@Override
	public String TreatedOrder(Model model) {
		model.addAttribute("orderlist",adminOrderDao.TreatedOrder());
		return "admin/TreatedOrder";
	}

	@Override
	public String CancelOrder(Model model) {
		model.addAttribute("orderlist",adminOrderDao.CancelOrder());
		return "admin/CancelOrder";
	}

}
