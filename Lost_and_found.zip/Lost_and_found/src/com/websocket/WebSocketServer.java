package com.websocket;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import org.springframework.stereotype.Component;

import net.sf.json.JSONObject;

@ServerEndpoint("/websocket/{id}")
@Component
public class WebSocketServer {
	private static ConcurrentHashMap<Integer, WebSocketServer> webSocketMap = new ConcurrentHashMap<Integer, WebSocketServer>();
	private Session session;//session为与某个客户端的连接会话，需要通过它来给客户端发送数据
	private Integer id;
	private Integer createrid;
	private String message;
	@OnOpen
	public void onOpen(@PathParam("id") Integer id,Session session) throws IOException {
		this.id = id;
		this.session = session;
		System.out.println(" 当前session是" + session.hashCode());
		webSocketMap.put(id, this);//当前用户的websocket
	}
	@OnClose
	public void onClose() throws IOException {	
		webSocketMap.remove(id);
	}
	@OnMessage
	public void onMessage(String jsonMsg, Session session) throws IOException {
		JSONObject jsonOject = JSONObject.fromObject(jsonMsg);
		id = Integer.parseInt(jsonOject.getString("id"));
		createrid = Integer.parseInt(jsonOject.getString("createrid"));
		message = jsonOject.getString("message");
		message = "来自" + id +"用户的信息：" + message + " \r\n";
		// 得到接收人
		WebSocketServer user = webSocketMap.get(createrid);
		if (user == null) {//如果接收人不存在则保持到数据库
			System.out.println("接收人不存在");
			return;
		}
		user.sendMessage(message);
	}
	@OnError
	public void onError(Session session, Throwable error) {
		System.out.println("发生错误");
		error.printStackTrace();
	}
	public void sendMessage(String message) throws IOException {
		this.session.getBasicRemote().sendText(message);//提供阻塞式的消息发送方式
			// this.session.getAsyncRemote().sendText(message);//提供非阻塞式的消息传输方式。
	}
}
