package com.controller.before;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.service.before.UserUserService;

@Controller
@RequestMapping("/userUser")
public class UserUserController extends BaseBeforeController{
	@Autowired
	private UserUserService useruserservice;
	@RequestMapping("/toChangePwd")
	public String toChangePwd() {
		return "before/changePwd";
	}
	@RequestMapping("/changePwd")
	public String changePwd(String oldbpwd,String newbpwd,Model model,HttpSession session) {
		return useruserservice.changePwd(oldbpwd,newbpwd,model,session);
	}
}
