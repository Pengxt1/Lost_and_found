package com.controller.before;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.dao.UserDao;
import com.exception.UserLoginNoException;
import com.po.Buser;
@Controller
public class BaseBeforeController {
	//登录权限控制
	@Autowired
	private UserDao userdao;
	@ModelAttribute
	public void isLogin(HttpSession session,HttpServletRequest request)
			throws UserLoginNoException{
		if(session.getAttribute("buser")==null) {
			throw new UserLoginNoException("没有登录");
		}
		else {
			Buser buser=(Buser)session.getAttribute("buser");
			Buser buser1=userdao.loginselect(buser);
			session.setAttribute("buser", buser1);
		}
	}
}