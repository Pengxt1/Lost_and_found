package com.controller.before;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.po.Order;

import com.service.before.UserOrderService;

@Controller
@RequestMapping("/userOrder")
public class UserOrderController extends BaseBeforeController{
	@Autowired
	private UserOrderService userOrderService;

	@RequestMapping(value="Order",produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String Order(int id,Model model,HttpSession session) {
		return userOrderService.Order(id,model,session);
	}
	
	@RequestMapping("MyorderedPrize")
	public String MyorderedPrize(Model model,HttpSession session) {
		return userOrderService.MyorderedPrize(model,session);
	}
	@RequestMapping("Cancel")
	public String Cancel(Order order,HttpSession session) {
		return userOrderService.Cancel(order,session);
	}
	@RequestMapping("MycancelledPrize")
	public String MycancelledPrize(Model model,HttpSession session) {
		return userOrderService.MycancelledPrize(model,session);
	}
	@RequestMapping("MyrecievedPrize")
	public String MyrecievedPrize(Model model,HttpSession session) {
		return userOrderService.MyrecievedPrize(model,session);
	}
}
