package com.controller.before;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.service.before.UserNoticeService;

@Controller
@RequestMapping("/userNotice")
public class UserNoticeController extends BaseBeforeController{
	@Autowired
	private UserNoticeService userNoticeService;
	@RequestMapping("/seeallselect")
	public String seeallselect(Model model) {
		return userNoticeService.seeallselect(model);
	}
	@RequestMapping("/selectANotice")
	public String seeallselect(Model model, Integer id) {
		return userNoticeService.selectANotice(model, id);
	}
}
