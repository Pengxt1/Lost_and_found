package com.controller.before;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


import com.service.before.UserPrizeService;

@Controller
@RequestMapping("/userPrize")
public class UserPrizeController extends BaseBeforeController{
	@Autowired
	private UserPrizeService userPrizeService;
	@RequestMapping("selectAllPrize")
	public String selectAllPrize(Model model) {
		return userPrizeService.selectAllPrize(model);
	}

}
