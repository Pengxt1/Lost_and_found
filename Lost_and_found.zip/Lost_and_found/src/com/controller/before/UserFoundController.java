package com.controller.before;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.po.Found;
import com.service.before.UserFoundService;

@Controller
@RequestMapping("/userFound")
public class UserFoundController extends BaseBeforeController{
	@Autowired
	private UserFoundService userFoundService;
	@RequestMapping("/toSeeTrusteeship")
	public String toSeeTrusteeship(Model model,HttpSession session) {
		return userFoundService.toSeeTrusteeship(model,session);
	}
	@RequestMapping("/toSee")
	public String toSee(Model model,HttpSession session) {
		return userFoundService.toSee(model,session);
	}
	@RequestMapping("/toSend")
	public String toSend(Model model) {
		return userFoundService.toSend(model);
	}
	@RequestMapping("/Send")
	public String Send(Found found,Model model,HttpSession session,HttpServletRequest request) {
		return userFoundService.Send(found,model,session,request);
	}
	@RequestMapping("/toDelete")
	public String toDelete(Model model,HttpSession session) {
		return userFoundService.toDelete(model,session);
	}
	@RequestMapping("/toSeeMyTrusteeship")
	public String toSeeMyTrusteeship(Model model,HttpSession session) {
		return userFoundService.toSeeMyTrusteeship(model,session);
	}
	@RequestMapping("/Delete")
	public String Delete(int id) {
		return userFoundService.Delete(id);
	}
	@RequestMapping("/Find")
	public String Find(int id) {
		return userFoundService.Find(id);
	}
	@RequestMapping("/UnFind")
	public String UnFind(int id) {
		return userFoundService.UnFind(id);
	}
}
