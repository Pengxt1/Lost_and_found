package com.controller.before;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.po.Lost;
import com.service.before.UserLostService;

@Controller
@RequestMapping("/userLost")
public class UserLostController extends BaseBeforeController{
	@Autowired
	private UserLostService userLostService;

	@RequestMapping("/toSee")
	public String toSee(Model model,HttpSession session) {
		return userLostService.toSee(model,session);
	}
	@RequestMapping("/toSend")
	public String toSend(Model model) {
		return userLostService.toSend(model);
	}
	@RequestMapping("/Send")
	public String Send(Lost lost,Model model,HttpSession session,HttpServletRequest request) {
		return userLostService.Send(lost,model,session,request);
	}
	@RequestMapping("/toDelete")
	public String toDelete(Model model,HttpSession session) {
		return userLostService.toDelete(model,session);
	}

	@RequestMapping("/Delete")
	public String Delete(int id) {
		return userLostService.Delete(id);
	}
	@RequestMapping("/Find")
	public String Find(int id) {
		return userLostService.Find(id);
	}
	@RequestMapping("/UnFind")
	public String UnFind(int id) {
		return userLostService.UnFind(id);
	}
}
