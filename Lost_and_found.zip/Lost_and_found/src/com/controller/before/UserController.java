package com.controller.before;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.po.Buser;
import com.service.before.UserService;

@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userservice;
	@RequestMapping("")
	public String toLogin() {
		return "before/login";
	}
	@RequestMapping("/toregister")
	public String toRegister() {
		return "before/register";
	}
	@RequestMapping("/register")
	public String register(Buser buser,Model model) {
		return userservice.register(buser,model);
	}
	@RequestMapping("/login")
	public String login(Buser buser,Model model,HttpSession session) {
		return userservice.login(buser,model,session);
	}
	@RequestMapping("/exit")
	public String exit(HttpSession session) {
		session.invalidate();
		return "before/login";
	}


}
