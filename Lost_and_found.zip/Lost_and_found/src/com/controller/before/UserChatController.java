package com.controller.before;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.service.before.UserChatService;

@Controller
@RequestMapping("/userChat")
public class UserChatController extends BaseBeforeController{
	@Autowired
	private UserChatService userChatService; 
	
	@RequestMapping("/toChat")
	public String toChat(String createrid,Model model) {
		return userChatService.toChat(createrid,model);
	}
	@RequestMapping("/toChat1")
	public String toChat1() {
		return userChatService.toChat1();
	}
}
