package com.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.service.admin.AdminLostService;

@Controller
@RequestMapping("/adminLost")
public class AdminLostController extends BaseAdminController{
	@Autowired
	private AdminLostService adminLostService;
	@RequestMapping("/toDelete")
	public String toDelete(Model model) {
		return adminLostService.toDelete(model);
	}
	@RequestMapping("/Delete")
	public String Delete(int id) {
		return adminLostService.Delete(id);
	}
	@RequestMapping("toCount")
	public String toCount(Model model) {
		return adminLostService.toCount(model);
	}
}
