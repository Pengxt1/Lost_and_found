package com.controller.admin;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.po.Auser;
import com.service.admin.AdminService;

@Controller
@RequestMapping("/admin")
public class AdminController{
	@Autowired
	private AdminService adminservice;
	@RequestMapping("")
	public String toLogin() {
		return "admin/login";
	}
	
	@RequestMapping("/login")
	public String login(Auser auser,Model model,HttpSession session) {
		return adminservice.login(auser,model,session);
		
	}

	@RequestMapping("/exit")
	public String exit(HttpSession session) {
		session.invalidate();
		return "admin/login";
	}
}
