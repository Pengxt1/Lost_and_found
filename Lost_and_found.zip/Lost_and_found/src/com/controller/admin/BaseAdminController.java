package com.controller.admin;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.dao.AdminDao;
import com.exception.AdminLoginNoException;
import com.po.Auser;

@Controller
public class BaseAdminController {
	//登录权限控制

	@ModelAttribute
	public void isLogin(HttpSession session,HttpServletRequest request)
			throws AdminLoginNoException{
		if(session.getAttribute("auser")==null) {
			throw new AdminLoginNoException("没有登录");
		}

	}
}
