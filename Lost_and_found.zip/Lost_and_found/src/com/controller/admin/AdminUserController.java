package com.controller.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.service.admin.AdminUserService;

@Controller
@RequestMapping("/adminUser")
public class AdminUserController extends BaseAdminController{
	@Autowired
	private AdminUserService adminUserService;
	
	@RequestMapping("/userInfo")
	public String userInfo(Model model) {
		return adminUserService.userInfo(model);
	}
	@RequestMapping("/deleteuserManager")
	public String deleteuserManager(Integer id) {
		return adminUserService.deleteuserManager(id);
	}
	@RequestMapping("/userSuspend")
	public String userSuspend(Model model) {
		return adminUserService.userSuspend(model);
	}
	@RequestMapping("/suspend")
	public String suspend(Integer id) {
		return adminUserService.suspend(id);
	}
	@RequestMapping("/unlock")
	public String unlock(Integer id) {
		return adminUserService.unlock(id);
	}
	@RequestMapping("/toChangeCredit")
	public String toChangeCredit(Model model) {
		return adminUserService.toChangeCredit(model);
	}
	@RequestMapping("/reduceCredit")
	public String reduceCredit(@RequestParam("createrid")int id,@RequestParam("reduce")int reduce) {
		return adminUserService.reduceCredit(id,reduce);
	}
	@RequestMapping("/addCredit")
	public String addCredit(@RequestParam("createrid")int id,@RequestParam("add")int add) {
		return adminUserService.addCredit(id,add);
	}
}
