package com.controller.admin;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.po.Order;
import com.service.admin.AdminOrderService;

@Controller
@RequestMapping("/adminOrder")
public class AdminOrderController extends BaseAdminController{
	@Autowired
	private AdminOrderService adminOrderService;
	@RequestMapping("untreatedOrder")
	public String untreatedOrder(Model model) {
		return adminOrderService.untreatedOrder(model);
	}
	@RequestMapping("TreatedOrder")
	public String TreatedOrder(Model model) {
		return adminOrderService.TreatedOrder(model);
	}
	@RequestMapping("CancelOrder")
	public String CancelOrder(Model model) {
		return adminOrderService.CancelOrder(model);
	}
	@RequestMapping("Cancel")
	public String Cancel(Order order,HttpSession session) {
		return adminOrderService.Cancel(order,session);
	}
	@RequestMapping(value="Recieve",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String Recieve(int id,int createrid,String bemail,String bpwd) {
		return adminOrderService.Recieve(id,createrid,bemail,bpwd);
	}
}
