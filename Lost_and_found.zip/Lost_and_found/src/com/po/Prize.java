package com.po;

import org.springframework.web.multipart.MultipartFile;

public class Prize {
	private Integer id;
	private String prizename;
	private String prizedescribe;
	private String pimage;
	private Integer pcredit;
	private Integer pamount;
	
	public Integer getPamount() {
		return pamount;
	}
	public void setPamount(Integer pamount) {
		this.pamount = pamount;
	}
	private MultipartFile pfile;
	
	public MultipartFile getPfile() {
		return pfile;
	}
	public void setPfile(MultipartFile pfile) {
		this.pfile = pfile;
	}
	public Integer getId() {
		return id;
	}
	public String getPrizename() {
		return prizename;
	}
	public String getPrizedescribe() {
		return prizedescribe;
	}
	public String getPimage() {
		return pimage;
	}
	public Integer getPcredit() {
		return pcredit;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	public void setPrizename(String prizename) {
		this.prizename = prizename;
	}
	public void setPrizedescribe(String prizedescribe) {
		this.prizedescribe = prizedescribe;
	}
	public void setPimage(String pimage) {
		this.pimage = pimage;
	}
	public void setPcredit(Integer pcredit) {
		this.pcredit = pcredit;
	}

}
