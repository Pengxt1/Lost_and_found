package com.po;

import org.springframework.web.multipart.MultipartFile;

public class Lost {
	private Integer id;
	private String ltypename;
	private String limage;
	private String lname;
	private String ldescribe;
	private String lcontact;
	private String ltime;
	private String lisfind;
	private Integer createrid;
	private MultipartFile lfile;
	
	public MultipartFile getLfile() {
		return lfile;
	}
	public void setLfile(MultipartFile lfile) {
		this.lfile = lfile;
	}
	public String getLimage() {
		return limage;
	}
	public void setLimage(String limage) {
		this.limage = limage;
	}
	public Integer getId() {
		return id;
	}
	public String getLtypename() {
		return ltypename;
	}
	public String getLname() {
		return lname;
	}
	public String getLdescribe() {
		return ldescribe;
	}
	public String getLcontact() {
		return lcontact;
	}
	public String getLtime() {
		return ltime;
	}
	public String getLisfind() {
		return lisfind;
	}
	public Integer getCreaterid() {
		return createrid;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public void setLtypename(String ltypename) {
		this.ltypename = ltypename;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public void setLdescribe(String ldescribe) {
		this.ldescribe = ldescribe;
	}
	public void setLcontact(String lcontact) {
		this.lcontact = lcontact;
	}
	public void setLtime(String ltime) {
		this.ltime = ltime;
	}
	public void setLisfind(String lisfind) {
		this.lisfind = lisfind;
	}
	public void setCreaterid(Integer createrid) {
		this.createrid = createrid;
	}
	
}
