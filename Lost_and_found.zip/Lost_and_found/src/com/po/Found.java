package com.po;

import org.springframework.web.multipart.MultipartFile;

public class Found {
	private Integer id;
	private String ftypename;
	private String fimage;
	private String fname;
	private String fdescribe;
	private String fcontact;
	private String ftime;
	private String fisfind;
	private Integer createrid;
	private MultipartFile ffile;
	private String istrusteeship;
	
	
	public String getIstrusteeship() {
		return istrusteeship;
	}
	public void setIstrusteeship(String istrusteeship) {
		this.istrusteeship = istrusteeship;
	}
	public MultipartFile getFfile() {
		return ffile;
	}
	public void setFfile(MultipartFile ffile) {
		this.ffile = ffile;
	}
	public String getFimage() {
		return fimage;
	}
	public void setFimage(String fimage) {
		this.fimage = fimage;
	}
	public Integer getId() {
		return id;
	}
	public String getFtypename() {
		return ftypename;
	}
	public String getFname() {
		return fname;
	}
	public String getFdescribe() {
		return fdescribe;
	}
	public String getFcontact() {
		return fcontact;
	}
	public String getFtime() {
		return ftime;
	}
	public String getFisfind() {
		return fisfind;
	}
	public Integer getCreaterid() {
		return createrid;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public void setFtypename(String ftypename) {
		this.ftypename = ftypename;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public void setFdescribe(String fdescribe) {
		this.fdescribe = fdescribe;
	}
	public void setFcontact(String fcontact) {
		this.fcontact = fcontact;
	}
	public void setFtime(String ftime) {
		this.ftime = ftime;
	}
	public void setFisfind(String fisfind) {
		this.fisfind = fisfind;
	}
	public void setCreaterid(Integer createrid) {
		this.createrid = createrid;
	}
	
}
