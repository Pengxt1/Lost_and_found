package com.po;

public class Order {
	private int id;
	private int prizeid;
	private String prizename;
	private String prizedescribe;
	private String pimage;
	private int pcredit;
	private int createrid;
	private String ordertime;
	private String endtime;
	private String closetime;
	private String state;
	
	public int getPrizeid() {
		return prizeid;
	}
	public void setPrizeid(int prizeid) {
		this.prizeid = prizeid;
	}
	public int getId() {
		return id;
	}
	public String getPrizename() {
		return prizename;
	}
	public String getPrizedescribe() {
		return prizedescribe;
	}
	public String getPimage() {
		return pimage;
	}
	public int getPcredit() {
		return pcredit;
	}
	public int getCreaterid() {
		return createrid;
	}
	public String getOrdertime() {
		return ordertime;
	}
	public String getEndtime() {
		return endtime;
	}
	public String getClosetime() {
		return closetime;
	}
	public String getState() {
		return state;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setPrizename(String prizename) {
		this.prizename = prizename;
	}
	public void setPrizedescribe(String prizedescribe) {
		this.prizedescribe = prizedescribe;
	}
	public void setPimage(String pimage) {
		this.pimage = pimage;
	}
	public void setPcredit(int pcredit) {
		this.pcredit = pcredit;
	}
	public void setCreaterid(int createrid) {
		this.createrid = createrid;
	}
	public void setOrdertime(String ordertime) {
		this.ordertime = ordertime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	public void setClosetime(String closetime) {
		this.closetime = closetime;
	}
	public void setState(String state) {
		this.state = state;
	}
	
}
