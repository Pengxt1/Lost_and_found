package com.po;

public class Buser {
	private Integer id;
	private String bemail;
	private String bpwd;
	private String bavailable;
	private Integer credit;
	
	public Integer getCredit() {
		return credit;
	}
	public void setCredit(Integer credit) {
		this.credit = credit;
	}
	public String getBavailable() {
		return bavailable;
	}
	public void setBavailable(String bavailable) {
		this.bavailable = bavailable;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getBemail() {
		return bemail;
	}
	public void setBemail(String bemail) {
		this.bemail = bemail;
	}
	public String getBpwd() {
		return bpwd;
	}
	public void setBpwd(String bpwd) {
		this.bpwd = bpwd;
	}
}
